package com.madhu.service;

import java.util.List;

import com.madhu.model.Registration;

public interface RegistrationService {

	public Long savePassenger(Registration p);

	public Registration getPassengerById(Long id);

	public List<Registration> getAllPassengers();

}
