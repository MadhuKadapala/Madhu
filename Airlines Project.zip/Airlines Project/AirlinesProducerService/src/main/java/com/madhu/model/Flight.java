package com.madhu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Flight_Details")

public class Flight {

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}

	public Flight() {
		super();
	}

	public Flight(Long id, String name, String source, String destination, String fare) {
		super();
		this.id = id;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // for mysql
	@Column(name = "Flight_id")
	private Long id;

	@Column(name = "Flight_name")
	private String name;

	@Column(name = "source")
	private String source;

	@Column(name = "dest")
	private String destination;

	@Column(name = "Flight_fare")
	private String fare;

}
